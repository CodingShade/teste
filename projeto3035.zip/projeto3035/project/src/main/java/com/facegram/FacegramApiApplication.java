package com.facegram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacegramApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(FacegramApiApplication.class, args);
    }
}